library(testthat)
library(magrittr)
library(EchoNet2Fish)

test_check("EchoNet2Fish")